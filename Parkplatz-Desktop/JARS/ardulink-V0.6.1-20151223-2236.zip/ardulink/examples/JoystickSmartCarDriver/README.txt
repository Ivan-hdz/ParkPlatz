To run this example: upload the sketch and then double click on joystick smart car driver jar.
