To run this example: upload the sketch and then double click on simple smart car driver jar.
